"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { CustomerForm } from "@/components/master-data/customer-form"
import { Search, Plus, Edit, Trash2, Users, Package, Building, Wrench } from "lucide-react"
import type { Customer, Vendor, Item, Asset } from "@/lib/types"

export default function MasterDataPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [showCustomerForm, setShowCustomerForm] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | undefined>()

  // Mock data - in production, this would come from API calls
  const customers: Customer[] = [
    {
      id: 1,
      customerCode: "CUST001",
      name: "Acme Corporation",
      email: "contact@acme.com",
      phone: "+1-555-0123",
      address: "123 Business St",
      city: "New York",
      state: "NY",
      zipCode: "10001",
      country: "USA",
      creditLimit: 50000,
      paymentTerms: 30,
      isActive: true,
      createdAt: "2024-01-15T10:00:00Z",
      updatedAt: "2024-01-15T10:00:00Z",
    },
    {
      id: 2,
      customerCode: "CUST002",
      name: "Global Industries",
      email: "orders@global.com",
      phone: "+1-555-0456",
      address: "456 Commerce Ave",
      city: "Los Angeles",
      state: "CA",
      zipCode: "90210",
      country: "USA",
      creditLimit: 75000,
      paymentTerms: 45,
      isActive: true,
      createdAt: "2024-01-20T14:30:00Z",
      updatedAt: "2024-01-20T14:30:00Z",
    },
  ]

  const vendors: Vendor[] = [
    {
      id: 1,
      vendorCode: "VEND001",
      name: "Office Supplies Co",
      email: "sales@officesupplies.com",
      phone: "+1-555-0789",
      address: "789 Supply Lane",
      city: "Chicago",
      state: "IL",
      zipCode: "60601",
      country: "USA",
      paymentTerms: 30,
      isActive: true,
      createdAt: "2024-01-10T09:00:00Z",
      updatedAt: "2024-01-10T09:00:00Z",
    },
  ]

  const items: Item[] = [
    {
      id: 1,
      itemCode: "ITEM001",
      name: "Office Chair",
      description: "Ergonomic office chair with lumbar support",
      category: "Furniture",
      unitOfMeasure: "Each",
      costPrice: 150.0,
      sellingPrice: 250.0,
      reorderLevel: 10,
      maxStockLevel: 100,
      isActive: true,
      isService: false,
      createdAt: "2024-01-12T11:00:00Z",
      updatedAt: "2024-01-12T11:00:00Z",
    },
  ]

  const assets: Asset[] = [
    {
      id: 1,
      assetCode: "ASSET001",
      name: "Production Machine A",
      description: "Main production line machine",
      category: "Machinery",
      location: "Factory Floor 1",
      purchaseDate: "2023-06-15",
      purchaseCost: 50000,
      currentValue: 45000,
      maintenanceSchedule: "Monthly",
      isActive: true,
      createdAt: "2023-06-15T08:00:00Z",
      updatedAt: "2024-01-01T10:00:00Z",
    },
  ]

  const handleCustomerSubmit = (customerData: Partial<Customer>) => {
    console.log("Customer data:", customerData)
    // In production, this would make an API call
  }

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.customerCode.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Master Data Management</h1>
        <p className="text-muted-foreground">Manage core business entities used across all modules</p>
      </div>

      <Tabs defaultValue="customers" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="customers" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Customers
          </TabsTrigger>
          <TabsTrigger value="vendors" className="flex items-center gap-2">
            <Building className="h-4 w-4" />
            Vendors
          </TabsTrigger>
          <TabsTrigger value="items" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            Items
          </TabsTrigger>
          <TabsTrigger value="assets" className="flex items-center gap-2">
            <Wrench className="h-4 w-4" />
            Assets
          </TabsTrigger>
        </TabsList>

        <TabsContent value="customers" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Customers</CardTitle>
                  <CardDescription>Manage customer information and credit terms</CardDescription>
                </div>
                <Button onClick={() => setShowCustomerForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Customer
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2 mb-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search customers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Credit Limit</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCustomers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-medium">{customer.customerCode}</TableCell>
                      <TableCell>{customer.name}</TableCell>
                      <TableCell>{customer.email}</TableCell>
                      <TableCell>{customer.phone}</TableCell>
                      <TableCell>${customer.creditLimit.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant={customer.isActive ? "default" : "secondary"}>
                          {customer.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedCustomer(customer)
                              setShowCustomerForm(true)
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="vendors" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Vendors</CardTitle>
              <CardDescription>Manage supplier and vendor information</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Vendor management interface coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="items" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Items & Products</CardTitle>
              <CardDescription>Manage inventory items and service offerings</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Item management interface coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assets" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Assets</CardTitle>
              <CardDescription>Manage company assets and equipment</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Asset management interface coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <CustomerForm
        customer={selectedCustomer}
        open={showCustomerForm}
        onOpenChange={(open) => {
          setShowCustomerForm(open)
          if (!open) setSelectedCustomer(undefined)
        }}
        onSubmit={handleCustomerSubmit}
      />
    </div>
  )
}
