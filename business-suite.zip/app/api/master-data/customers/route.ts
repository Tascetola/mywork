import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/database"
import type { Customer } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = (page - 1) * limit

    let query = "SELECT * FROM customers WHERE is_active = true"
    const params: any[] = []

    if (search) {
      query += " AND (name ILIKE $1 OR customer_code ILIKE $1 OR email ILIKE $1)"
      params.push(`%${search}%`)
    }

    query += ` ORDER BY name LIMIT $${params.length + 1} OFFSET $${params.length + 2}`
    params.push(limit, offset)

    const customers = await db.query<Customer>(query, params)

    // Get total count for pagination
    let countQuery = "SELECT COUNT(*) as total FROM customers WHERE is_active = true"
    const countParams: any[] = []

    if (search) {
      countQuery += " AND (name ILIKE $1 OR customer_code ILIKE $1 OR email ILIKE $1)"
      countParams.push(`%${search}%`)
    }

    const [{ total }] = await db.query<{ total: number }>(countQuery, countParams)

    return NextResponse.json({
      customers,
      pagination: {
        page,
        limit,
        total: Number.parseInt(total.toString()),
        pages: Math.ceil(Number.parseInt(total.toString()) / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching customers:", error)
    return NextResponse.json({ error: "Failed to fetch customers" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      customerCode,
      name,
      email,
      phone,
      address,
      city,
      state,
      zipCode,
      country,
      taxId,
      creditLimit,
      paymentTerms,
    } = body

    const query = `
      INSERT INTO customers (
        customer_code, name, email, phone, address, city, state, 
        zip_code, country, tax_id, credit_limit, payment_terms
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `

    const [customer] = await db.query<Customer>(query, [
      customerCode,
      name,
      email,
      phone,
      address,
      city,
      state,
      zipCode,
      country,
      taxId,
      creditLimit || 0,
      paymentTerms || 30,
    ])

    return NextResponse.json(customer, { status: 201 })
  } catch (error) {
    console.error("Error creating customer:", error)
    return NextResponse.json({ error: "Failed to create customer" }, { status: 500 })
  }
}
