import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/database"
import type { Item } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const category = searchParams.get("category")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = (page - 1) * limit

    let query = "SELECT * FROM items WHERE is_active = true"
    const params: any[] = []

    if (search) {
      query += " AND (name ILIKE $1 OR item_code ILIKE $1 OR description ILIKE $1)"
      params.push(`%${search}%`)
    }

    if (category) {
      query += ` AND category = $${params.length + 1}`
      params.push(category)
    }

    query += ` ORDER BY name LIMIT $${params.length + 1} OFFSET $${params.length + 2}`
    params.push(limit, offset)

    const items = await db.query<Item>(query, params)

    // Get categories for filter
    const categories = await db.query<{ category: string }>(
      "SELECT DISTINCT category FROM items WHERE category IS NOT NULL AND is_active = true ORDER BY category",
    )

    return NextResponse.json({
      items,
      categories: categories.map((c) => c.category),
      pagination: {
        page,
        limit,
        total: 0, // Would calculate from count query
        pages: 1,
      },
    })
  } catch (error) {
    console.error("Error fetching items:", error)
    return NextResponse.json({ error: "Failed to fetch items" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      itemCode,
      name,
      description,
      category,
      unitOfMeasure,
      costPrice,
      sellingPrice,
      reorderLevel,
      maxStockLevel,
      isService,
    } = body

    const query = `
      INSERT INTO items (
        item_code, name, description, category, unit_of_measure,
        cost_price, selling_price, reorder_level, max_stock_level, is_service
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `

    const [item] = await db.query<Item>(query, [
      itemCode,
      name,
      description,
      category,
      unitOfMeasure,
      costPrice || 0,
      sellingPrice || 0,
      reorderLevel || 0,
      maxStockLevel || 0,
      isService || false,
    ])

    return NextResponse.json(item, { status: 201 })
  } catch (error) {
    console.error("Error creating item:", error)
    return NextResponse.json({ error: "Failed to create item" }, { status: 500 })
  }
}
