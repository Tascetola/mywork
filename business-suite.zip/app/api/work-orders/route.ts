import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"
import { verifyAuth } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get("status")
    const priority = searchParams.get("priority")
    const type = searchParams.get("type")
    const assignedTo = searchParams.get("assignedTo")

    let sql = `
      SELECT wo.*, 
             a.name as asset_name, 
             u.first_name || ' ' || u.last_name as assigned_technician_name,
             c.first_name || ' ' || c.last_name as created_by_name
      FROM work_orders wo
      LEFT JOIN assets a ON wo.asset_id = a.id
      LEFT JOIN users u ON wo.assigned_to = u.id
      LEFT JOIN users c ON wo.created_by = c.id
      WHERE 1=1
    `
    const params: any[] = []

    if (status) {
      sql += ` AND wo.status = $${params.length + 1}`
      params.push(status)
    }

    if (priority) {
      sql += ` AND wo.priority = $${params.length + 1}`
      params.push(priority)
    }

    if (type) {
      sql += ` AND wo.work_order_type = $${params.length + 1}`
      params.push(type)
    }

    if (assignedTo) {
      sql += ` AND wo.assigned_to = $${params.length + 1}`
      params.push(assignedTo)
    }

    sql += ` ORDER BY wo.created_at DESC`

    const result = await query(sql, params)
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching work orders:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { title, description, workOrderType, priority, assetId, assignedTo, scheduledDate, estimatedHours } = body

    // Generate work order number
    const woNumberResult = await query(
      "SELECT COALESCE(MAX(CAST(SUBSTRING(work_order_number FROM 4) AS INTEGER)), 0) + 1 as next_number FROM work_orders WHERE work_order_number LIKE 'WO-%'",
    )
    const workOrderNumber = `WO-${String(woNumberResult.rows[0].next_number).padStart(6, "0")}`

    const result = await query(
      `INSERT INTO work_orders (
        work_order_number, title, description, work_order_type, priority,
        asset_id, assigned_to, scheduled_date, estimated_hours, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [
        workOrderNumber,
        title,
        description,
        workOrderType,
        priority || "medium",
        assetId,
        assignedTo,
        scheduledDate,
        estimatedHours || 0,
        user.id,
      ],
    )

    return NextResponse.json(result.rows[0], { status: 201 })
  } catch (error) {
    console.error("Error creating work order:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
