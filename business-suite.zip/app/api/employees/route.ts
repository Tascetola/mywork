import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"
import { verifyAuth } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const department = searchParams.get("department")
    const isActive = searchParams.get("active")

    let sql = `
      SELECT e.*, u.name as user_name, m.first_name as manager_first_name, m.last_name as manager_last_name
      FROM employees e
      LEFT JOIN users u ON e.user_id = u.id
      LEFT JOIN employees m ON e.manager_id = m.id
      WHERE 1=1
    `
    const params: any[] = []

    if (department) {
      sql += ` AND e.department = $${params.length + 1}`
      params.push(department)
    }

    if (isActive !== null) {
      sql += ` AND e.is_active = $${params.length + 1}`
      params.push(isActive === "true")
    }

    sql += ` ORDER BY e.last_name, e.first_name`

    const result = await query(sql, params)
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching employees:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user || !["admin", "manager"].includes(user.role)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const {
      userId,
      firstName,
      lastName,
      email,
      phone,
      hireDate,
      jobTitle,
      department,
      managerId,
      salaryType,
      baseSalary,
      hourlyRate,
    } = body

    // Generate employee number
    const empNumberResult = await query(
      "SELECT COALESCE(MAX(CAST(SUBSTRING(employee_number FROM 4) AS INTEGER)), 0) + 1 as next_number FROM employees WHERE employee_number LIKE 'EMP%'",
    )
    const employeeNumber = `EMP${String(empNumberResult.rows[0].next_number).padStart(3, "0")}`

    const result = await query(
      `INSERT INTO employees (user_id, employee_number, first_name, last_name, email, phone, hire_date, job_title, department, manager_id, salary_type, base_salary, hourly_rate)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *`,
      [
        userId,
        employeeNumber,
        firstName,
        lastName,
        email,
        phone,
        hireDate,
        jobTitle,
        department,
        managerId,
        salaryType,
        baseSalary,
        hourlyRate,
      ],
    )

    // Initialize leave balances for new employee
    const currentYear = new Date().getFullYear()
    await query(
      `INSERT INTO leave_balances (employee_id, leave_type, year, allocated, remaining) VALUES 
       ($1, 'vacation', $2, 20, 20), ($1, 'sick', $2, 10, 10)`,
      [result.rows[0].id, currentYear],
    )

    return NextResponse.json(result.rows[0], { status: 201 })
  } catch (error) {
    console.error("Error creating employee:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
