import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"
import { verifyAuth } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")
    const cashierId = searchParams.get("cashierId")

    let sql = `
      SELECT pt.*, 
             u.first_name || ' ' || u.last_name as cashier_name,
             c.name as customer_name
      FROM pos_transactions pt
      LEFT JOIN users u ON pt.cashier_id = u.id
      LEFT JOIN customers c ON pt.customer_id = c.id
      WHERE 1=1
    `
    const params: any[] = []

    if (startDate) {
      sql += ` AND DATE(pt.transaction_date) >= $${params.length + 1}`
      params.push(startDate)
    }

    if (endDate) {
      sql += ` AND DATE(pt.transaction_date) <= $${params.length + 1}`
      params.push(endDate)
    }

    if (cashierId) {
      sql += ` AND pt.cashier_id = $${params.length + 1}`
      params.push(cashierId)
    }

    sql += ` ORDER BY pt.transaction_date DESC`

    const result = await query(sql, params)
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching POS transactions:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { customerId, items, paymentMethod, amountPaid, discountAmount } = body

    // Generate transaction number
    const transactionNumberResult = await query(
      "SELECT COALESCE(MAX(CAST(SUBSTRING(transaction_number FROM 4) AS INTEGER)), 0) + 1 as next_number FROM pos_transactions WHERE transaction_number LIKE 'TXN%'",
    )
    const transactionNumber = `TXN${String(transactionNumberResult.rows[0].next_number).padStart(6, "0")}`

    // Calculate totals
    const subtotal = items.reduce((sum: number, item: any) => sum + item.quantity * item.price, 0)
    const taxAmount = subtotal * 0.075 // 7.5% VAT
    const totalAmount = subtotal + taxAmount - (discountAmount || 0)

    // Create transaction
    const transactionResult = await query(
      `INSERT INTO pos_transactions (
        transaction_number, customer_id, subtotal, tax_amount, discount_amount,
        total_amount, payment_method, amount_paid, cashier_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [
        transactionNumber,
        customerId,
        subtotal,
        taxAmount,
        discountAmount || 0,
        totalAmount,
        paymentMethod,
        amountPaid,
        user.id,
      ],
    )

    const transactionId = transactionResult.rows[0].id

    // Add transaction items
    for (const item of items) {
      await query(
        `INSERT INTO pos_transaction_items (transaction_id, item_id, quantity, unit_price, total_price)
         VALUES ($1, $2, $3, $4, $5)`,
        [transactionId, item.itemId, item.quantity, item.price, item.quantity * item.price],
      )

      // Update inventory
      await query(`UPDATE inventory SET quantity_on_hand = quantity_on_hand - $1 WHERE item_id = $2`, [
        item.quantity,
        item.itemId,
      ])
    }

    return NextResponse.json(transactionResult.rows[0], { status: 201 })
  } catch (error) {
    console.error("Error creating POS transaction:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
