import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"
import { verifyAuth } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get("status")
    const vendor = searchParams.get("vendor")

    let sql = `
      SELECT po.*, v.name as vendor_name, u.name as created_by_name
      FROM purchase_orders po
      LEFT JOIN vendors v ON po.vendor_id = v.id
      LEFT JOIN users u ON po.created_by = u.id
      WHERE 1=1
    `
    const params: any[] = []

    if (status) {
      sql += ` AND po.status = $${params.length + 1}`
      params.push(status)
    }

    if (vendor) {
      sql += ` AND po.vendor_id = $${params.length + 1}`
      params.push(vendor)
    }

    sql += ` ORDER BY po.created_at DESC`

    const result = await query(sql, params)
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching purchase orders:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { vendor_id, delivery_date, items } = body

    // Generate PO number
    const poNumberResult = await query(
      "SELECT COALESCE(MAX(CAST(SUBSTRING(po_number FROM 3) AS INTEGER)), 0) + 1 as next_number FROM purchase_orders WHERE po_number LIKE 'PO%'",
    )
    const poNumber = `PO${String(poNumberResult.rows[0].next_number).padStart(6, "0")}`

    // Calculate total
    const total = items.reduce((sum: number, item: any) => sum + item.quantity * item.unit_price, 0)

    // Create purchase order
    const poResult = await query(
      `INSERT INTO purchase_orders (po_number, vendor_id, delivery_date, total_amount, created_by)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [poNumber, vendor_id, delivery_date, total, user.id],
    )

    const poId = poResult.rows[0].id

    // Add items
    for (const item of items) {
      await query(
        `INSERT INTO purchase_order_items (po_id, item_id, quantity, unit_price)
         VALUES ($1, $2, $3, $4)`,
        [poId, item.item_id, item.quantity, item.unit_price],
      )
    }

    return NextResponse.json(poResult.rows[0], { status: 201 })
  } catch (error) {
    console.error("Error creating purchase order:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
