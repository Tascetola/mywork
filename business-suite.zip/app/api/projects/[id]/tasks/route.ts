import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const projectId = Number.parseInt(params.id)

    const query = `
      SELECT pt.*, 
             u.first_name || ' ' || u.last_name as assigned_user_name,
             COUNT(st.id) as subtask_count
      FROM project_tasks pt
      LEFT JOIN users u ON pt.assigned_to = u.id
      LEFT JOIN project_tasks st ON pt.id = st.parent_task_id
      WHERE pt.project_id = $1
      GROUP BY pt.id, u.first_name, u.last_name
      ORDER BY pt.created_at ASC
    `

    const tasks = await db.query<any>(query, [projectId])

    return NextResponse.json({
      tasks: tasks.map((t) => ({
        id: t.id,
        projectId: t.project_id,
        parentTaskId: t.parent_task_id,
        taskCode: t.task_code,
        name: t.name,
        description: t.description,
        status: t.status,
        priority: t.priority,
        plannedStartDate: t.planned_start_date,
        plannedEndDate: t.planned_end_date,
        actualStartDate: t.actual_start_date,
        actualEndDate: t.actual_end_date,
        estimatedHours: Number.parseFloat(t.estimated_hours),
        actualHours: Number.parseFloat(t.actual_hours),
        progressPercentage: t.progress_percentage,
        assignedTo: t.assigned_to,
        createdAt: t.created_at,
        updatedAt: t.updated_at,
        assignedUserName: t.assigned_user_name,
        subtaskCount: Number.parseInt(t.subtask_count),
      })),
    })
  } catch (error) {
    console.error("Error fetching project tasks:", error)
    return NextResponse.json({ error: "Failed to fetch project tasks" }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const projectId = Number.parseInt(params.id)
    const body = await request.json()
    const {
      parentTaskId,
      taskCode,
      name,
      description,
      status,
      priority,
      plannedStartDate,
      plannedEndDate,
      estimatedHours,
      assignedTo,
    } = body

    const query = `
      INSERT INTO project_tasks (
        project_id, parent_task_id, task_code, name, description, status, priority,
        planned_start_date, planned_end_date, estimated_hours, assigned_to, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `

    const [task] = await db.query<any>(query, [
      projectId,
      parentTaskId,
      taskCode,
      name,
      description,
      status || "not_started",
      priority || "medium",
      plannedStartDate,
      plannedEndDate,
      estimatedHours || 0,
      assignedTo,
      1, // TODO: Get from session
    ])

    return NextResponse.json(
      {
        id: task.id,
        projectId: task.project_id,
        parentTaskId: task.parent_task_id,
        taskCode: task.task_code,
        name: task.name,
        description: task.description,
        status: task.status,
        priority: task.priority,
        plannedStartDate: task.planned_start_date,
        plannedEndDate: task.planned_end_date,
        actualStartDate: task.actual_start_date,
        actualEndDate: task.actual_end_date,
        estimatedHours: Number.parseFloat(task.estimated_hours),
        actualHours: Number.parseFloat(task.actual_hours),
        progressPercentage: task.progress_percentage,
        assignedTo: task.assigned_to,
        createdAt: task.created_at,
        updatedAt: task.updated_at,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Error creating project task:", error)
    return NextResponse.json({ error: "Failed to create project task" }, { status: 500 })
  }
}
