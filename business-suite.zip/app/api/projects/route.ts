import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const status = searchParams.get("status")
    const managerId = searchParams.get("managerId")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = (page - 1) * limit

    let query = `
      SELECT p.*, 
             u.first_name || ' ' || u.last_name as project_manager_name,
             c.name as customer_name,
             COUNT(pt.id) as task_count,
             AVG(pt.progress_percentage) as avg_task_progress
      FROM projects p
      LEFT JOIN users u ON p.project_manager_id = u.id
      LEFT JOIN customers c ON p.customer_id = c.id
      LEFT JOIN project_tasks pt ON p.id = pt.project_id
      WHERE p.is_active = true
    `
    const params: any[] = []

    if (search) {
      query += ` AND (p.name ILIKE $${params.length + 1} OR p.project_code ILIKE $${params.length + 1})`
      params.push(`%${search}%`)
    }

    if (status) {
      query += ` AND p.status = $${params.length + 1}`
      params.push(status)
    }

    if (managerId) {
      query += ` AND p.project_manager_id = $${params.length + 1}`
      params.push(Number.parseInt(managerId))
    }

    query += ` GROUP BY p.id, u.first_name, u.last_name, c.name`
    query += ` ORDER BY p.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`
    params.push(limit, offset)

    const projects = await db.query<any>(query, params)

    return NextResponse.json({
      projects: projects.map((p) => ({
        id: p.id,
        projectCode: p.project_code,
        name: p.name,
        description: p.description,
        status: p.status,
        priority: p.priority,
        startDate: p.start_date,
        endDate: p.end_date,
        budget: Number.parseFloat(p.budget),
        actualCost: Number.parseFloat(p.actual_cost),
        progressPercentage: p.progress_percentage,
        projectManagerId: p.project_manager_id,
        customerId: p.customer_id,
        isActive: p.is_active,
        createdAt: p.created_at,
        updatedAt: p.updated_at,
        projectManagerName: p.project_manager_name,
        customerName: p.customer_name,
        taskCount: Number.parseInt(p.task_count),
        avgTaskProgress: Number.parseFloat(p.avg_task_progress) || 0,
      })),
      pagination: {
        page,
        limit,
        total: 0, // Would calculate from count query
        pages: 1,
      },
    })
  } catch (error) {
    console.error("Error fetching projects:", error)
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      projectCode,
      name,
      description,
      status,
      priority,
      startDate,
      endDate,
      budget,
      projectManagerId,
      customerId,
    } = body

    const query = `
      INSERT INTO projects (
        project_code, name, description, status, priority,
        start_date, end_date, budget, project_manager_id, customer_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `

    const [project] = await db.query<any>(query, [
      projectCode,
      name,
      description,
      status || "planning",
      priority || "medium",
      startDate,
      endDate,
      budget || 0,
      projectManagerId,
      customerId,
      1, // TODO: Get from session
    ])

    return NextResponse.json(
      {
        id: project.id,
        projectCode: project.project_code,
        name: project.name,
        description: project.description,
        status: project.status,
        priority: project.priority,
        startDate: project.start_date,
        endDate: project.end_date,
        budget: Number.parseFloat(project.budget),
        actualCost: Number.parseFloat(project.actual_cost),
        progressPercentage: project.progress_percentage,
        projectManagerId: project.project_manager_id,
        customerId: project.customer_id,
        isActive: project.is_active,
        createdAt: project.created_at,
        updatedAt: project.updated_at,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Error creating project:", error)
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 })
  }
}
