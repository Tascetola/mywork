import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/database"
import { verifyAuth } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get("status")
    const customer = searchParams.get("customer")

    let sql = `
      SELECT so.*, c.name as customer_name, u.name as created_by_name
      FROM sales_orders so
      LEFT JOIN customers c ON so.customer_id = c.id
      LEFT JOIN users u ON so.created_by = u.id
      WHERE 1=1
    `
    const params: any[] = []

    if (status) {
      sql += ` AND so.status = $${params.length + 1}`
      params.push(status)
    }

    if (customer) {
      sql += ` AND so.customer_id = $${params.length + 1}`
      params.push(customer)
    }

    sql += ` ORDER BY so.created_at DESC`

    const result = await query(sql, params)
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching sales orders:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { customer_id, delivery_date, items } = body

    // Generate order number
    const orderNumberResult = await query(
      "SELECT COALESCE(MAX(CAST(SUBSTRING(order_number FROM 3) AS INTEGER)), 0) + 1 as next_number FROM sales_orders WHERE order_number LIKE 'SO%'",
    )
    const orderNumber = `SO${String(orderNumberResult.rows[0].next_number).padStart(6, "0")}`

    // Calculate total
    const total = items.reduce((sum: number, item: any) => sum + item.quantity * item.unit_price, 0)

    // Create sales order
    const orderResult = await query(
      `INSERT INTO sales_orders (order_number, customer_id, delivery_date, total_amount, created_by)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [orderNumber, customer_id, delivery_date, total, user.id],
    )

    const orderId = orderResult.rows[0].id

    // Add items
    for (const item of items) {
      await query(
        `INSERT INTO sales_order_items (order_id, item_id, quantity, unit_price)
         VALUES ($1, $2, $3, $4)`,
        [orderId, item.item_id, item.quantity, item.unit_price],
      )
    }

    return NextResponse.json(orderResult.rows[0], { status: 201 })
  } catch (error) {
    console.error("Error creating sales order:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
