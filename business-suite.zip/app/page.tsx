import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  FolderKanban,
  Wrench,
  ShoppingCart,
  Users,
  ReceiptIcon as CashRegister,
  AlertTriangle,
  CheckCircle,
  Clock,
} from "lucide-react"

export default function DashboardPage() {
  const stats = [
    {
      title: "Active Projects",
      value: "12",
      change: "+2 from last month",
      icon: FolderKanban,
      color: "text-blue-600",
    },
    {
      title: "Open Work Orders",
      value: "34",
      change: "+5 from yesterday",
      icon: Wrench,
      color: "text-orange-600",
    },
    {
      title: "Pending POs",
      value: "8",
      change: "-3 from last week",
      icon: ShoppingCart,
      color: "text-green-600",
    },
    {
      title: "Active Employees",
      value: "156",
      change: "+4 this month",
      icon: Users,
      color: "text-purple-600",
    },
  ]

  const recentActivities = [
    {
      id: 1,
      type: "project",
      title: 'New project "Office Renovation" created',
      time: "2 hours ago",
      status: "info",
    },
    {
      id: 2,
      type: "work-order",
      title: "Work Order #WO-2024-001 completed",
      time: "4 hours ago",
      status: "success",
    },
    {
      id: 3,
      type: "purchase",
      title: "Purchase Order #PO-2024-045 requires approval",
      time: "6 hours ago",
      status: "warning",
    },
    {
      id: 4,
      type: "hr",
      title: "Payroll processing completed for January",
      time: "1 day ago",
      status: "success",
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "info":
      default:
        return <Clock className="h-4 w-4 text-blue-600" />
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to your integrated business management suite</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">{stat.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
            <CardDescription>Latest updates across all modules</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3">
                  {getStatusIcon(activity.status)}
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">{activity.title}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks across modules</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              <button className="flex items-center gap-3 rounded-lg border p-3 text-left hover:bg-accent transition-colors">
                <FolderKanban className="h-4 w-4 text-blue-600" />
                <div>
                  <p className="text-sm font-medium">Create New Project</p>
                  <p className="text-xs text-muted-foreground">Start a new project with tasks</p>
                </div>
              </button>
              <button className="flex items-center gap-3 rounded-lg border p-3 text-left hover:bg-accent transition-colors">
                <Wrench className="h-4 w-4 text-orange-600" />
                <div>
                  <p className="text-sm font-medium">Create Work Order</p>
                  <p className="text-xs text-muted-foreground">Schedule maintenance or repair</p>
                </div>
              </button>
              <button className="flex items-center gap-3 rounded-lg border p-3 text-left hover:bg-accent transition-colors">
                <ShoppingCart className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-sm font-medium">New Purchase Order</p>
                  <p className="text-xs text-muted-foreground">Order supplies or materials</p>
                </div>
              </button>
              <button className="flex items-center gap-3 rounded-lg border p-3 text-left hover:bg-accent transition-colors">
                <CashRegister className="h-4 w-4 text-purple-600" />
                <div>
                  <p className="text-sm font-medium">Open POS Terminal</p>
                  <p className="text-xs text-muted-foreground">Process sales transactions</p>
                </div>
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
