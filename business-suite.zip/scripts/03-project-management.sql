-- Project Management Module Schema

-- Projects
CREATE TABLE IF NOT EXISTS projects (
    id SERIAL PRIMARY KEY,
    project_code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'planning', -- planning, active, on_hold, completed, cancelled
    priority VARCHAR(20) DEFAULT 'medium', -- low, medium, high, critical
    start_date DATE,
    end_date DATE,
    planned_start_date DATE,
    planned_end_date DATE,
    budget DECIMAL(15,2) DEFAULT 0,
    actual_cost DECIMAL(15,2) DEFAULT 0,
    progress_percentage INTEGER DEFAULT 0,
    project_manager_id INTEGER REFERENCES users(id),
    customer_id INTEGER REFERENCES customers(id),
    gl_account_id INTEGER REFERENCES gl_accounts(id),
    is_active BOOLEAN DEFAULT true,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Project Tasks (WBS - Work Breakdown Structure)
CREATE TABLE IF NOT EXISTS project_tasks (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    parent_task_id INTEGER REFERENCES project_tasks(id),
    task_code VARCHAR(50),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'not_started', -- not_started, in_progress, completed, on_hold, cancelled
    priority VARCHAR(20) DEFAULT 'medium',
    planned_start_date DATE,
    planned_end_date DATE,
    actual_start_date DATE,
    actual_end_date DATE,
    estimated_hours DECIMAL(8,2) DEFAULT 0,
    actual_hours DECIMAL(8,2) DEFAULT 0,
    progress_percentage INTEGER DEFAULT 0,
    assigned_to INTEGER REFERENCES users(id),
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Project Resources
CREATE TABLE IF NOT EXISTS project_resources (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id),
    role VARCHAR(100), -- Project Manager, Developer, Designer, etc.
    allocation_percentage INTEGER DEFAULT 100, -- % of time allocated
    hourly_rate DECIMAL(10,2) DEFAULT 0,
    start_date DATE,
    end_date DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Time Tracking
CREATE TABLE IF NOT EXISTS time_entries (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    task_id INTEGER REFERENCES project_tasks(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id),
    date DATE NOT NULL,
    hours DECIMAL(8,2) NOT NULL,
    description TEXT,
    billable BOOLEAN DEFAULT true,
    hourly_rate DECIMAL(10,2),
    total_cost DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'draft', -- draft, submitted, approved, rejected
    approved_by INTEGER REFERENCES users(id),
    approved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Project Milestones
CREATE TABLE IF NOT EXISTS project_milestones (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE NOT NULL,
    completed_date DATE,
    status VARCHAR(20) DEFAULT 'pending', -- pending, completed, overdue
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Project Expenses
CREATE TABLE IF NOT EXISTS project_expenses (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    task_id INTEGER REFERENCES project_tasks(id),
    expense_type VARCHAR(100) NOT NULL, -- materials, travel, equipment, etc.
    description TEXT,
    amount DECIMAL(15,2) NOT NULL,
    expense_date DATE NOT NULL,
    vendor_id INTEGER REFERENCES vendors(id),
    receipt_number VARCHAR(100),
    gl_account_id INTEGER REFERENCES gl_accounts(id),
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, paid
    submitted_by INTEGER REFERENCES users(id),
    approved_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Task Dependencies
CREATE TABLE IF NOT EXISTS task_dependencies (
    id SERIAL PRIMARY KEY,
    predecessor_task_id INTEGER REFERENCES project_tasks(id) ON DELETE CASCADE,
    successor_task_id INTEGER REFERENCES project_tasks(id) ON DELETE CASCADE,
    dependency_type VARCHAR(20) DEFAULT 'finish_to_start', -- finish_to_start, start_to_start, finish_to_finish, start_to_finish
    lag_days INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(predecessor_task_id, successor_task_id)
);

-- Project Documents
CREATE TABLE IF NOT EXISTS project_documents (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    task_id INTEGER REFERENCES project_tasks(id),
    name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500),
    file_size INTEGER,
    mime_type VARCHAR(100),
    version VARCHAR(20) DEFAULT '1.0',
    uploaded_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_manager ON projects(project_manager_id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_project ON project_tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_assigned ON project_tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_time_entries_project ON time_entries(project_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_user ON time_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_date ON time_entries(date);

-- Insert sample data
INSERT INTO projects (project_code, name, description, status, priority, start_date, end_date, budget, project_manager_id, created_by) VALUES
('PROJ001', 'Office Renovation', 'Complete renovation of main office building', 'active', 'high', '2024-02-01', '2024-04-30', 150000.00, 1, 1),
('PROJ002', 'Website Redesign', 'Redesign company website with modern UI/UX', 'planning', 'medium', '2024-03-01', '2024-05-15', 75000.00, 1, 1),
('PROJ003', 'ERP Implementation', 'Implement new ERP system across all departments', 'active', 'critical', '2024-01-15', '2024-08-31', 500000.00, 1, 1)
ON CONFLICT (project_code) DO NOTHING;

-- Insert sample tasks
INSERT INTO project_tasks (project_id, task_code, name, description, status, planned_start_date, planned_end_date, estimated_hours, assigned_to, created_by) VALUES
(1, 'TASK001', 'Design Phase', 'Create architectural designs and plans', 'completed', '2024-02-01', '2024-02-15', 120, 1, 1),
(1, 'TASK002', 'Demolition', 'Remove old fixtures and prepare space', 'in_progress', '2024-02-16', '2024-02-28', 80, 1, 1),
(1, 'TASK003', 'Electrical Work', 'Install new electrical systems', 'not_started', '2024-03-01', '2024-03-15', 100, 1, 1),
(2, 'TASK004', 'Requirements Gathering', 'Collect and document website requirements', 'in_progress', '2024-03-01', '2024-03-10', 40, 1, 1),
(2, 'TASK005', 'UI/UX Design', 'Create wireframes and visual designs', 'not_started', '2024-03-11', '2024-03-25', 60, 1, 1)
ON CONFLICT DO NOTHING;

-- Insert sample milestones
INSERT INTO project_milestones (project_id, name, description, due_date, created_by) VALUES
(1, 'Design Approval', 'All designs approved by stakeholders', '2024-02-15', 1),
(1, 'Phase 1 Complete', 'Demolition and preparation complete', '2024-02-28', 1),
(2, 'Requirements Sign-off', 'All requirements documented and approved', '2024-03-10', 1),
(3, 'System Selection', 'ERP system vendor selected', '2024-02-29', 1)
ON CONFLICT DO NOTHING;
