-- Authentication and Role Management Schema

-- Roles and Permissions
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default roles
INSERT INTO roles (name, description) VALUES
('admin', 'System Administrator - Full access to all modules'),
('manager', 'Department Manager - Access to assigned modules with approval rights'),
('project_manager', 'Project Manager - Full access to Project Management module'),
('hr_manager', 'HR Manager - Full access to HR and Payroll modules'),
('finance_manager', 'Finance Manager - Access to financial data across modules'),
('purchasing_manager', 'Purchasing Manager - Full access to Purchasing module'),
('sales_manager', 'Sales Manager - Full access to Sales and CRM modules'),
('warehouse_manager', 'Warehouse Manager - Access to Inventory and Work Orders'),
('employee', 'Regular Employee - Limited access based on department'),
('technician', 'Field Technician - Access to Work Orders and mobile app'),
('cashier', 'POS Cashier - Access to Point of Sale system only')
ON CONFLICT (name) DO NOTHING;

-- Permissions
CREATE TABLE IF NOT EXISTS permissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    module VARCHAR(50) NOT NULL,
    action VARCHAR(50) NOT NULL, -- create, read, update, delete, approve
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default permissions
INSERT INTO permissions (name, description, module, action) VALUES
-- Project Management
('projects.create', 'Create new projects', 'projects', 'create'),
('projects.read', 'View projects', 'projects', 'read'),
('projects.update', 'Edit projects', 'projects', 'update'),
('projects.delete', 'Delete projects', 'projects', 'delete'),
('projects.approve', 'Approve project budgets', 'projects', 'approve'),

-- Work Orders
('work_orders.create', 'Create work orders', 'work_orders', 'create'),
('work_orders.read', 'View work orders', 'work_orders', 'read'),
('work_orders.update', 'Edit work orders', 'work_orders', 'update'),
('work_orders.delete', 'Delete work orders', 'work_orders', 'delete'),
('work_orders.assign', 'Assign technicians', 'work_orders', 'assign'),

-- Purchasing
('purchasing.create', 'Create purchase orders', 'purchasing', 'create'),
('purchasing.read', 'View purchase orders', 'purchasing', 'read'),
('purchasing.update', 'Edit purchase orders', 'purchasing', 'update'),
('purchasing.approve', 'Approve purchase orders', 'purchasing', 'approve'),

-- Sales
('sales.create', 'Create sales orders', 'sales', 'create'),
('sales.read', 'View sales orders', 'sales', 'read'),
('sales.update', 'Edit sales orders', 'sales', 'update'),
('sales.approve', 'Approve discounts', 'sales', 'approve'),

-- HR & Payroll
('hr.create', 'Create employee records', 'hr', 'create'),
('hr.read', 'View employee records', 'hr', 'read'),
('hr.update', 'Edit employee records', 'hr', 'update'),
('payroll.process', 'Process payroll', 'payroll', 'create'),
('payroll.approve', 'Approve payroll', 'payroll', 'approve'),

-- POS
('pos.create', 'Process sales transactions', 'pos', 'create'),
('pos.read', 'View POS reports', 'pos', 'read'),
('pos.refund', 'Process refunds', 'pos', 'update'),

-- Master Data
('master_data.create', 'Create master data', 'master_data', 'create'),
('master_data.read', 'View master data', 'master_data', 'read'),
('master_data.update', 'Edit master data', 'master_data', 'update'),
('master_data.delete', 'Delete master data', 'master_data', 'delete'),

-- System Settings
('settings.read', 'View system settings', 'settings', 'read'),
('settings.update', 'Edit system settings', 'settings', 'update'),
('users.manage', 'Manage user accounts', 'users', 'create')
ON CONFLICT (name) DO NOTHING;

-- Role Permissions Junction
CREATE TABLE IF NOT EXISTS role_permissions (
    id SERIAL PRIMARY KEY,
    role_id INTEGER REFERENCES roles(id) ON DELETE CASCADE,
    permission_id INTEGER REFERENCES permissions(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(role_id, permission_id)
);

-- User Sessions
CREATE TABLE IF NOT EXISTS user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User Role Assignments (users can have multiple roles)
CREATE TABLE IF NOT EXISTS user_roles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    role_id INTEGER REFERENCES roles(id) ON DELETE CASCADE,
    assigned_by INTEGER REFERENCES users(id),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    UNIQUE(user_id, role_id)
);

-- Audit Log for security tracking
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100),
    record_id INTEGER,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    role VARCHAR(50),
    department VARCHAR(50),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user
INSERT INTO users (email, password_hash, first_name, last_name, employee_id, role, department, is_active) VALUES
('admin@admin.com', 'cGFzc3dvcmQxMjM=', 'System', 'Administrator', 'ADMIN001', 'admin', 'IT', true)
ON CONFLICT (email) DO NOTHING;

-- Assign admin role to default admin user
INSERT INTO user_roles (user_id, role_id, assigned_by)
SELECT u.id, r.id, u.id
FROM users u, roles r 
WHERE u.email = 'admin@admin.com' AND r.name = 'admin'
ON CONFLICT (user_id, role_id) DO NOTHING;

-- Grant default permissions to roles
-- Admin gets all permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM roles r, permissions p 
WHERE r.name = 'admin'
ON CONFLICT DO NOTHING;

-- Manager gets most permissions except user management
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM roles r, permissions p 
WHERE r.name = 'manager' 
AND p.name NOT IN ('users.manage', 'settings.update')
ON CONFLICT DO NOTHING;

-- Project Manager gets project-related permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM roles r, permissions p 
WHERE r.name = 'project_manager' 
AND p.module IN ('projects', 'work_orders', 'master_data')
ON CONFLICT DO NOTHING;
