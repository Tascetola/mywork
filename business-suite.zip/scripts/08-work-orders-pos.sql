-- Work Orders Tables
CREATE TABLE IF NOT EXISTS work_orders (
    id SERIAL PRIMARY KEY,
    work_order_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    work_order_type VARCHAR(50) NOT NULL CHECK (work_order_type IN ('preventive', 'corrective', 'emergency')),
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
    priority VARCHAR(50) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    asset_id INTEGER REFERENCES assets(id),
    assigned_to INTEGER REFERENCES users(id),
    scheduled_date TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    estimated_hours DECIMAL(10,2) DEFAULT 0,
    actual_hours DECIMAL(10,2) DEFAULT 0,
    estimated_cost DECIMAL(15,2) DEFAULT 0,
    actual_cost DECIMAL(15,2) DEFAULT 0,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Work Order Items (parts/materials used)
CREATE TABLE IF NOT EXISTS work_order_items (
    id SERIAL PRIMARY KEY,
    work_order_id INTEGER REFERENCES work_orders(id) ON DELETE CASCADE,
    item_id INTEGER REFERENCES items(id),
    quantity_used DECIMAL(10,2) NOT NULL,
    unit_cost DECIMAL(10,2) NOT NULL,
    total_cost DECIMAL(15,2) GENERATED ALWAYS AS (quantity_used * unit_cost) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- POS Transactions
CREATE TABLE IF NOT EXISTS pos_transactions (
    id SERIAL PRIMARY KEY,
    transaction_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INTEGER REFERENCES customers(id),
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    subtotal DECIMAL(15,2) NOT NULL,
    tax_amount DECIMAL(15,2) DEFAULT 0,
    discount_amount DECIMAL(15,2) DEFAULT 0,
    total_amount DECIMAL(15,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL CHECK (payment_method IN ('cash', 'card', 'transfer', 'pos')),
    amount_paid DECIMAL(15,2) NOT NULL,
    change_amount DECIMAL(15,2) GENERATED ALWAYS AS (amount_paid - total_amount) STORED,
    cashier_id INTEGER REFERENCES users(id),
    status VARCHAR(50) DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'refunded')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- POS Transaction Items
CREATE TABLE IF NOT EXISTS pos_transaction_items (
    id SERIAL PRIMARY KEY,
    transaction_id INTEGER REFERENCES pos_transactions(id) ON DELETE CASCADE,
    item_id INTEGER REFERENCES items(id),
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(15,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inventory table for stock tracking
CREATE TABLE IF NOT EXISTS inventory (
    id SERIAL PRIMARY KEY,
    item_id INTEGER REFERENCES items(id) UNIQUE,
    quantity_on_hand DECIMAL(10,2) DEFAULT 0,
    reserved_quantity DECIMAL(10,2) DEFAULT 0,
    available_quantity DECIMAL(10,2) GENERATED ALWAYS AS (quantity_on_hand - reserved_quantity) STORED,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample work orders
INSERT INTO work_orders (work_order_number, title, description, work_order_type, priority, scheduled_date, estimated_hours, created_by) VALUES
('WO-000001', 'HVAC System Maintenance', 'Quarterly maintenance of HVAC system in main building', 'preventive', 'medium', '2024-02-01 09:00:00', 4.0, 1),
('WO-000002', 'Printer Repair', 'Fix paper jam issue in office printer', 'corrective', 'high', '2024-01-25 14:00:00', 1.5, 1),
('WO-000003', 'Emergency Generator Check', 'Monthly inspection of backup generator', 'preventive', 'low', '2024-02-05 10:00:00', 2.0, 1);

-- Insert sample inventory records
INSERT INTO inventory (item_id, quantity_on_hand) VALUES
(1, 50), -- Office Chair
(2, 25), -- Laptop Stand  
(3, 30); -- Desk Lamp

-- Insert sample POS transactions
INSERT INTO pos_transactions (transaction_number, subtotal, tax_amount, total_amount, payment_method, amount_paid, cashier_id) VALUES
('TXN000001', 25000.00, 1875.00, 26875.00, 'card', 26875.00, 1),
('TXN000002', 8500.00, 637.50, 9137.50, 'cash', 10000.00, 1);

-- Insert sample transaction items
INSERT INTO pos_transaction_items (transaction_id, item_id, quantity, unit_price, total_price) VALUES
(1, 1, 1, 25000.00, 25000.00), -- Office Chair
(2, 2, 1, 8500.00, 8500.00);   -- Laptop Stand

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_assigned_to ON work_orders(assigned_to);
CREATE INDEX IF NOT EXISTS idx_work_orders_scheduled_date ON work_orders(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_pos_transactions_date ON pos_transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_pos_transactions_cashier ON pos_transactions(cashier_id);
