// Core Types for Business Suite Application

export interface User {
  id: number
  email: string
  firstName: string
  lastName: string
  employeeId?: string
  phone?: string
  role: "admin" | "manager" | "employee" | "cashier" | "technician"
  department?: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface Currency {
  id: number
  currencyCode: string
  currencyName: string
  symbol: string
  exchangeRate: number
  isBaseCurrency: boolean
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface CurrencyFormatOptions {
  currency?: string
  showSymbol?: boolean
  decimals?: number
}

export interface MonetaryAmount {
  amount: number
  currency: string
}

export interface Customer {
  id: number
  customerCode: string
  name: string
  email?: string
  phone?: string
  address?: string
  city?: string
  state?: string
  zipCode?: string
  country?: string
  taxId?: string
  creditLimit: MonetaryAmount
  paymentTerms: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface Vendor {
  id: number
  vendorCode: string
  name: string
  email?: string
  phone?: string
  address?: string
  city?: string
  state?: string
  zipCode?: string
  country?: string
  taxId?: string
  paymentTerms: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface Item {
  id: number
  itemCode: string
  name: string
  description?: string
  category?: string
  unitOfMeasure: string
  costPrice: MonetaryAmount
  sellingPrice: MonetaryAmount
  reorderLevel: number
  maxStockLevel: number
  isActive: boolean
  isService: boolean
  createdAt: string
  updatedAt: string
}

export interface Asset {
  id: number
  assetCode: string
  name: string
  description?: string
  category?: string
  location?: string
  purchaseDate?: string
  purchaseCost?: MonetaryAmount
  currentValue?: MonetaryAmount
  maintenanceSchedule?: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface GLAccount {
  id: number
  accountCode: string
  accountName: string
  accountType: "Asset" | "Liability" | "Equity" | "Revenue" | "Expense"
  parentAccountId?: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface SystemSetting {
  id: number
  settingKey: string
  settingValue: string
  description?: string
  createdAt: string
  updatedAt: string
}

// Project Management types
export interface Project {
  id: number
  projectCode: string
  name: string
  description?: string
  status: "planning" | "active" | "on_hold" | "completed" | "cancelled"
  priority: "low" | "medium" | "high" | "critical"
  startDate?: string
  endDate?: string
  plannedStartDate?: string
  plannedEndDate?: string
  budget: MonetaryAmount
  actualCost: MonetaryAmount
  progressPercentage: number
  projectManagerId?: number
  customerId?: number
  glAccountId?: number
  isActive: boolean
  createdBy?: number
  createdAt: string
  updatedAt: string
  // Computed fields
  projectManager?: User
  customer?: Customer
  tasks?: ProjectTask[]
  resources?: ProjectResource[]
  milestones?: ProjectMilestone[]
}

export interface ProjectTask {
  id: number
  projectId: number
  parentTaskId?: number
  taskCode?: string
  name: string
  description?: string
  status: "not_started" | "in_progress" | "completed" | "on_hold" | "cancelled"
  priority: "low" | "medium" | "high" | "critical"
  plannedStartDate?: string
  plannedEndDate?: string
  actualStartDate?: string
  actualEndDate?: string
  estimatedHours: number
  actualHours: number
  progressPercentage: number
  assignedTo?: number
  createdBy?: number
  createdAt: string
  updatedAt: string
  // Computed fields
  assignedUser?: User
  subtasks?: ProjectTask[]
  dependencies?: TaskDependency[]
}

export interface ProjectResource {
  id: number
  projectId: number
  userId: number
  role: string
  allocationPercentage: number
  hourlyRate: MonetaryAmount
  startDate?: string
  endDate?: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  // Computed fields
  user?: User
}

export interface TimeEntry {
  id: number
  projectId: number
  taskId?: number
  userId: number
  date: string
  hours: number
  description?: string
  billable: boolean
  hourlyRate?: MonetaryAmount
  totalCost?: MonetaryAmount
  status: "draft" | "submitted" | "approved" | "rejected"
  approvedBy?: number
  approvedAt?: string
  createdAt: string
  updatedAt: string
  // Computed fields
  user?: User
  project?: Project
  task?: ProjectTask
}

export interface ProjectMilestone {
  id: number
  projectId: number
  name: string
  description?: string
  dueDate: string
  completedDate?: string
  status: "pending" | "completed" | "overdue"
  createdBy?: number
  createdAt: string
  updatedAt: string
}

export interface ProjectExpense {
  id: number
  projectId: number
  taskId?: number
  expenseType: string
  description?: string
  amount: MonetaryAmount
  expenseDate: string
  vendorId?: number
  receiptNumber?: string
  glAccountId?: number
  status: "pending" | "approved" | "paid"
  submittedBy?: number
  approvedBy?: number
  createdAt: string
  updatedAt: string
  // Computed fields
  vendor?: Vendor
  project?: Project
  task?: ProjectTask
}

export interface TaskDependency {
  id: number
  predecessorTaskId: number
  successorTaskId: number
  dependencyType: "finish_to_start" | "start_to_start" | "finish_to_finish" | "start_to_finish"
  lagDays: number
  createdAt: string
}

// Work Order Management types
export interface WorkOrder {
  id: number
  workOrderNumber: string
  title: string
  description?: string
  type: "preventive" | "corrective" | "emergency" | "project"
  priority: "low" | "medium" | "high" | "critical"
  status: "open" | "assigned" | "in_progress" | "completed" | "cancelled"
  assetId?: number
  locationId?: number
  requestedBy: number
  assignedTo?: number
  scheduledDate?: string
  completedDate?: string
  estimatedHours: number
  actualHours: number
  estimatedCost: MonetaryAmount
  actualCost: MonetaryAmount
  createdAt: string
  updatedAt: string
  // Computed fields
  asset?: Asset
  requestedByUser?: User
  assignedToUser?: User
  tasks?: WorkOrderTask[]
  materials?: WorkOrderMaterial[]
}

export interface WorkOrderTask {
  id: number
  workOrderId: number
  taskNumber: number
  description: string
  status: "pending" | "in_progress" | "completed"
  assignedTo?: number
  estimatedHours: number
  actualHours: number
  completedAt?: string
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface WorkOrderMaterial {
  id: number
  workOrderId: number
  itemId: number
  quantityRequired: number
  quantityUsed: number
  unitCost: MonetaryAmount
  totalCost: MonetaryAmount
  createdAt: string
  updatedAt: string
  // Computed fields
  item?: Item
}

// Purchasing & Sales types
export interface PurchaseRequisition {
  id: number
  requisitionNumber: string
  requestedBy: number
  department?: string
  status: "pending" | "approved" | "rejected" | "converted"
  priority: "normal" | "urgent" | "emergency"
  requiredDate?: string
  totalAmount: MonetaryAmount
  approvedBy?: number
  approvedAt?: string
  createdAt: string
  updatedAt: string
  // Computed fields
  requestedByUser?: User
  approvedByUser?: User
  items?: PurchaseRequisitionItem[]
}

export interface PurchaseRequisitionItem {
  id: number
  requisitionId: number
  itemId: number
  quantity: number
  unitPrice: MonetaryAmount
  totalPrice: MonetaryAmount
  // Computed fields
  item?: Item
}

export interface PurchaseOrder {
  id: number
  po_number: string
  vendor_id?: number
  requisition_id?: number
  status: "draft" | "pending" | "approved" | "received" | "cancelled"
  order_date: string
  delivery_date?: string
  total_amount: MonetaryAmount
  tax_amount: MonetaryAmount
  created_by?: number
  approved_by?: number
  created_at: string
  updated_at: string
  // Computed fields
  vendor_name?: string
  created_by_name?: string
  items?: PurchaseOrderItem[]
}

export interface PurchaseOrderItem {
  id: number
  poId: number
  itemId: number
  quantity: number
  unitPrice: MonetaryAmount
  totalPrice: MonetaryAmount
  // Computed fields
  item?: Item
}

export interface SalesQuote {
  id: number
  quoteNumber: string
  customerId: number
  status: "draft" | "sent" | "accepted" | "rejected" | "expired"
  quoteDate: string
  validUntil?: string
  totalAmount: MonetaryAmount
  taxAmount: MonetaryAmount
  createdBy: number
  createdAt: string
  updatedAt: string
  // Computed fields
  customer?: Customer
  createdByUser?: User
  items?: SalesQuoteItem[]
}

export interface SalesQuoteItem {
  id: number
  quoteId: number
  itemId: number
  quantity: number
  unitPrice: MonetaryAmount
  totalPrice: MonetaryAmount
  // Computed fields
  item?: Item
}

export interface SalesOrder {
  id: number
  orderNumber: string
  customerId: number
  quoteId?: number
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
  orderDate: string
  deliveryDate?: string
  totalAmount: MonetaryAmount
  taxAmount: MonetaryAmount
  createdBy: number
  createdAt: string
  updatedAt: string
  // Computed fields
  customer?: Customer
  createdByUser?: User
  items?: SalesOrderItem[]
}

export interface SalesOrderItem {
  id: number
  orderId: number
  itemId: number
  quantity: number
  unitPrice: MonetaryAmount
  totalPrice: MonetaryAmount
  // Computed fields
  item?: Item
}

// HR & Payroll types
export interface Employee {
  id: number
  userId: number
  employeeNumber: string
  firstName: string
  lastName: string
  email: string
  phone?: string
  address?: string
  city?: string
  state?: string
  zipCode?: string
  dateOfBirth?: string
  hireDate: string
  terminationDate?: string
  jobTitle: string
  department: string
  managerId?: number
  salaryType: "hourly" | "salary" | "contract"
  baseSalary: MonetaryAmount
  hourlyRate?: MonetaryAmount
  payFrequency: "weekly" | "biweekly" | "monthly"
  bankAccount?: string
  taxId?: string
  emergencyContact?: string
  emergencyPhone?: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  // Computed fields
  user?: User
  manager?: Employee
  directReports?: Employee[]
}

export interface Attendance {
  id: number
  employeeId: number
  date: string
  clockIn?: string
  clockOut?: string
  breakStart?: string
  breakEnd?: string
  totalHours: number
  regularHours: number
  overtimeHours: number
  status: "present" | "absent" | "late" | "half_day" | "holiday"
  notes?: string
  approvedBy?: number
  createdAt: string
  updatedAt: string
  // Computed fields
  employee?: Employee
}

export interface LeaveRequest {
  id: number
  employeeId: number
  leaveType: "vacation" | "sick" | "personal" | "maternity" | "paternity" | "bereavement"
  startDate: string
  endDate: string
  totalDays: number
  reason?: string
  status: "pending" | "approved" | "rejected" | "cancelled"
  appliedDate: string
  approvedBy?: number
  approvedDate?: string
  rejectionReason?: string
  createdAt: string
  updatedAt: string
  // Computed fields
  employee?: Employee
  approver?: User
}

export interface LeaveBalance {
  id: number
  employeeId: number
  leaveType: "vacation" | "sick" | "personal" | "maternity" | "paternity" | "bereavement"
  year: number
  allocated: number
  used: number
  remaining: number
  carryForward: number
  createdAt: string
  updatedAt: string
}

export interface PayrollPeriod {
  id: number
  periodName: string
  startDate: string
  endDate: string
  payDate: string
  status: "draft" | "processing" | "completed" | "paid"
  totalGrossPay: MonetaryAmount
  totalDeductions: MonetaryAmount
  totalNetPay: MonetaryAmount
  processedBy?: number
  processedAt?: string
  createdAt: string
  updatedAt: string
}

export interface Payslip {
  id: number
  employeeId: number
  payrollPeriodId: number
  payslipNumber: string
  regularHours: number
  overtimeHours: number
  regularPay: MonetaryAmount
  overtimePay: MonetaryAmount
  grossPay: MonetaryAmount
  taxDeductions: MonetaryAmount
  socialSecurityDeductions: MonetaryAmount
  healthInsuranceDeductions: MonetaryAmount
  otherDeductions: MonetaryAmount
  totalDeductions: MonetaryAmount
  netPay: MonetaryAmount
  status: "draft" | "finalized" | "paid"
  createdAt: string
  updatedAt: string
  // Computed fields
  employee?: Employee
  payrollPeriod?: PayrollPeriod
}

export interface PerformanceReview {
  id: number
  employeeId: number
  reviewerId: number
  reviewPeriod: string
  reviewDate: string
  overallRating: number
  goals?: string
  achievements?: string
  areasForImprovement?: string
  comments?: string
  status: "draft" | "submitted" | "completed"
  createdAt: string
  updatedAt: string
  // Computed fields
  employee?: Employee
  reviewer?: User
}

export interface Training {
  id: number
  title: string
  description?: string
  provider?: string
  duration: number
  cost?: MonetaryAmount
  isRequired: boolean
  expiryMonths?: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface EmployeeTraining {
  id: number
  employeeId: number
  trainingId: number
  completedDate?: string
  expiryDate?: string
  score?: number
  certificateNumber?: string
  status: "assigned" | "in_progress" | "completed" | "expired"
  createdAt: string
  updatedAt: string
  // Computed fields
  employee?: Employee
  training?: Training
}

// Common interfaces for all modules
export interface BaseEntity {
  id: number
  createdAt: string
  updatedAt: string
}

export interface AuditLog {
  id: number
  tableName: string
  recordId: number
  action: "CREATE" | "UPDATE" | "DELETE"
  oldValues?: Record<string, any>
  newValues?: Record<string, any>
  userId: number
  timestamp: string
}

export interface WorkflowStatus {
  id: number
  name: string
  description?: string
  color: string
  isActive: boolean
}

export interface ApprovalChain {
  id: number
  name: string
  description?: string
  steps: ApprovalStep[]
  isActive: boolean
}

export interface ApprovalStep {
  id: number
  stepOrder: number
  approverRole: string
  approverUserId?: number
  isRequired: boolean
  conditions?: Record<string, any>
}
