"use client"

import type React from "react"
import { createContext, useContext, useState } from "react"
import type { AuthUser } from "@/lib/auth"

interface AuthContextType {
  user: AuthUser | null
  loading: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => Promise<void>
  hasPermission: (permission: string) => boolean
  hasRole: (role: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user] = useState<AuthUser | null>({
    id: 1,
    email: "admin@admin.com",
    firstName: "Admin",
    lastName: "User",
    employeeId: "EMP001",
    phone: "",
    role: "admin",
    department: "IT",
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    roles: ["admin"],
    permissions: ["*"],
  })

  const login = async (): Promise<boolean> => true
  const logout = async () => {}
  const hasPermission = (): boolean => true
  const hasRole = (): boolean => true

  return (
    <AuthContext.Provider value={{ user, loading: false, login, logout, hasPermission, hasRole }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
