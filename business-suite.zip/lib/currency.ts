export const DEFAULT_CURRENCY = "NGN"
export const CURRENCY_SYMBOL = "₦"

export interface CurrencyFormatOptions {
  currency?: string
  showSymbol?: boolean
  decimals?: number
}

export function formatCurrency(amount: number, options: CurrencyFormatOptions = {}): string {
  const { currency = DEFAULT_CURRENCY, showSymbol = true, decimals = 2 } = options

  const formattedAmount = amount.toLocaleString("en-NG", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })

  if (showSymbol && currency === "NGN") {
    return `${CURRENCY_SYMBOL}${formattedAmount}`
  }

  return showSymbol ? `${currency} ${formattedAmount}` : formattedAmount
}

export function convertCurrency(
  amount: number,
  fromCurrency: string,
  toCurrency: string,
  exchangeRates: Record<string, number>,
): number {
  if (fromCurrency === toCurrency) return amount

  // Convert to base currency (NGN) first, then to target currency
  const baseAmount = fromCurrency === "NGN" ? amount : amount / exchangeRates[fromCurrency]
  return toCurrency === "NGN" ? baseAmount : baseAmount * exchangeRates[toCurrency]
}
