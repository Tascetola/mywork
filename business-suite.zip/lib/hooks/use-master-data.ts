"use client"

import { useState, useEffect } from "react"
import type { Customer, Vendor, Item } from "@/lib/types"

interface UseMasterDataOptions {
  search?: string
  page?: number
  limit?: number
}

interface MasterDataResponse<T> {
  data: T[]
  loading: boolean
  error: string | null
  pagination?: {
    page: number
    limit: number
    total: number
    pages: number
  }
  refetch: () => void
}

export function useCustomers(options: UseMasterDataOptions = {}): MasterDataResponse<Customer> {
  const [data, setData] = useState<Customer[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [pagination, setPagination] = useState<any>(null)

  const fetchCustomers = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (options.search) params.append("search", options.search)
      if (options.page) params.append("page", options.page.toString())
      if (options.limit) params.append("limit", options.limit.toString())

      const response = await fetch(`/api/master-data/customers?${params}`)
      if (!response.ok) throw new Error("Failed to fetch customers")

      const result = await response.json()
      setData(result.customers)
      setPagination(result.pagination)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchCustomers()
  }, [options.search, options.page, options.limit])

  return {
    data,
    loading,
    error,
    pagination,
    refetch: fetchCustomers,
  }
}

export function useVendors(options: UseMasterDataOptions = {}): MasterDataResponse<Vendor> {
  const [data, setData] = useState<Vendor[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchVendors = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (options.search) params.append("search", options.search)

      const response = await fetch(`/api/master-data/vendors?${params}`)
      if (!response.ok) throw new Error("Failed to fetch vendors")

      const result = await response.json()
      setData(result.vendors)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchVendors()
  }, [options.search])

  return {
    data,
    loading,
    error,
    refetch: fetchVendors,
  }
}

export function useItems(options: UseMasterDataOptions = {}): MasterDataResponse<Item> {
  const [data, setData] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchItems = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/master-data/items")
      if (!response.ok) throw new Error("Failed to fetch items")

      const result = await response.json()
      setData(result.items)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchItems()
  }, [])

  return {
    data,
    loading,
    error,
    refetch: fetchItems,
  }
}
