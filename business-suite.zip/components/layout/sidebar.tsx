"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  LayoutDashboard,
  FolderKanban,
  Wrench,
  ShoppingCart,
  Users,
  ReceiptIcon as CashRegister,
  Settings,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

const navigation = [
  {
    name: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
  },
  {
    name: "Project Management",
    href: "/projects",
    icon: FolderKanban,
    children: [
      { name: "Projects", href: "/projects" },
      { name: "Tasks", href: "/projects/tasks" },
      { name: "Resources", href: "/projects/resources" },
      { name: "Time Tracking", href: "/projects/time-tracking" },
    ],
  },
  {
    name: "Work Orders",
    href: "/work-orders",
    icon: Wrench,
    children: [
      { name: "All Work Orders", href: "/work-orders" },
      { name: "Preventive Maintenance", href: "/work-orders/preventive" },
      { name: "Assets", href: "/work-orders/assets" },
    ],
  },
  {
    name: "Purchasing & Sales",
    href: "/purchasing",
    icon: ShoppingCart,
    children: [
      { name: "Purchase Orders", href: "/purchasing/orders" },
      { name: "Sales Orders", href: "/sales/orders" },
      { name: "Vendors", href: "/purchasing/vendors" },
      { name: "Customers", href: "/sales/customers" },
      { name: "Inventory", href: "/inventory" },
    ],
  },
  {
    name: "HR & Payroll",
    href: "/hr",
    icon: Users,
    children: [
      { name: "Employees", href: "/hr/employees" },
      { name: "Payroll", href: "/hr/payroll" },
      { name: "Time & Attendance", href: "/hr/attendance" },
      { name: "Leave Management", href: "/hr/leave" },
    ],
  },
  {
    name: "Point of Sale",
    href: "/pos",
    icon: CashRegister,
    children: [
      { name: "Sales Terminal", href: "/pos/terminal" },
      { name: "Transactions", href: "/pos/transactions" },
      { name: "Reports", href: "/pos/reports" },
    ],
  },
  {
    name: "Settings",
    href: "/settings",
    icon: Settings,
    children: [
      { name: "System Settings", href: "/settings/system" },
      { name: "User Management", href: "/settings/users" },
      { name: "Master Data", href: "/settings/master-data" },
    ],
  },
]

interface SidebarProps {
  className?: string
}

export function Sidebar({ className }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false)
  const pathname = usePathname()

  return (
    <div className={cn("flex flex-col border-r bg-background", collapsed ? "w-16" : "w-64", className)}>
      <div className="flex h-16 items-center justify-between px-4 border-b">
        {!collapsed && <h2 className="text-lg font-semibold">Business Suite</h2>}
        <Button variant="ghost" size="sm" onClick={() => setCollapsed(!collapsed)} className="h-8 w-8 p-0">
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      <ScrollArea className="flex-1 px-2 py-4">
        <nav className="space-y-2">
          {navigation.map((item) => (
            <div key={item.name}>
              <Link
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors",
                  pathname === item.href ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                  collapsed && "justify-center px-2",
                )}
              >
                <item.icon className="h-4 w-4 flex-shrink-0" />
                {!collapsed && <span>{item.name}</span>}
              </Link>

              {!collapsed && item.children && (
                <div className="ml-6 mt-1 space-y-1">
                  {item.children.map((child) => (
                    <Link
                      key={child.name}
                      href={child.href}
                      className={cn(
                        "block rounded-lg px-3 py-1 text-xs hover:bg-accent hover:text-accent-foreground transition-colors",
                        pathname === child.href ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                      )}
                    >
                      {child.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </ScrollArea>
    </div>
  )
}
